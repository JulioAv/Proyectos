/*
 * File:   i2c_apds.c
 * Author: vema3
 *
 * Created on August 26, 2021, 5:00 PM
 */


#include <xc.h>

void main(void) {
    return;
}
